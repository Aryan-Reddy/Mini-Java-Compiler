package visitor;
class PrintErr
{
	PrintErr()
	{
		System.out.println("Type Error");
		System.exit(0);
	}
}