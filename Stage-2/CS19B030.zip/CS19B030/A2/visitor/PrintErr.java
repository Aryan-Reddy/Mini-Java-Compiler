package visitor;
class PrintErr
{
	PrintErr()
	{
		System.out.println("Type error");
		System.exit(0);
	}
}